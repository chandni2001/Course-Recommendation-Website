<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Course Recommendation</title>
    <!--/google-fonts-->
    <link href="//fonts.googleapis.com/css2?family=Nunito:ital,wght@0,400;0,600;0,700;1,400&display=swap"
        rel="stylesheet">
    <!--//google-fonts-->
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">

</head>

<body>
    <!--header-->
    <header id="site-header" class="fixed-top">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-dark stroke">
                <h1>


                    Course Recommendation
                  </h1>
    <button class="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse"
                    data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span class="navbar-toggler-icon fa icon-close fa-times"></span>
                    </span>
                </button>

                <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                    <nav class="mr-auto ml-lg-5">
                        <div class="search-bar">
                            <form class="search">
                                <input type="search" class="search__input" name="search"
                                    placeholder="Search for Courses.." onload="equalWidth()" required>
                                <span class="fa fa-search search__icon"></span>
                            </form>
                        </div>
                    </nav>
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.html">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="services.html">Courses</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>
                <!-- toggle switch for light and dark theme -->

                <div class="mobile-position">
                    <nav class="navigation">
                        <div class="theme-switch-wrapper">
                            <label class="theme-switch" for="checkbox">
                                <input type="checkbox" id="checkbox">
                                <div class="mode-container py-1">
                                    <i class="gg-sun"></i>
                                    <i class="gg-moon"></i>
                                </div>
                            </label>
                        </div>
                    </nav>
                </div>
                <!-- //toggle switch for light and dark theme -->
            </nav>
        </div>
    </header>

    <section class="w3l-main-slider" id="home">
        <div class="companies20-content">
            <div class="owl-one owl-carousel owl-theme">
                <div class="item">
                    <li>
                        <div class="slider-info banner-view bg bg2">
                            <div class="banner-info">
                                <div class="container">
                                    <div class="banner-info-bg">
                                        <h5>A Great Place for Learning</h5>
                                        <p class="mt-4 pr-lg-4">

                                            Choose courses from the different fields and
                                            many new courses will be continue adding
                                          </p>
                                        <a class="btn btn-style btn-primary mt-xl-5 mt-4 mr-2" href="about.html"> Get
                                            Started <span class="fa fa-chevron-right ml-2"
                                                aria-hidden="true"></span></a>
                                        <a class="btn btn-style btn-white mt-xl-5 mt-4" href="services.html"> View
                                            Courses <span class="fa fa-chevron-right ml-2"
                                                aria-hidden="true"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </div>
                <div class="item">
                    <li>
                        <div class="slider-info  banner-view banner-top1 bg bg2">
                            <div class="banner-info">
                                <div class="container">
                                    <div class="banner-info-bg">
                                        <h5>Learning to Love, Loving to Learn</h5>
                                        <p class="mt-4 pr-lg-4">
                                            Choose courses from the different fields and
                                            many new courses will be continue adding</p>
                                        <a class="btn btn-style btn-primary mt-xl-5 mt-4 mr-2" href="about.html"> Get
                                            Started <span class="fa fa-chevron-right ml-2"
                                                aria-hidden="true"></span></a>
                                        <a class="btn btn-style btn-white mt-xl-5 mt-4" href="services.html"> View
                                            Courses <span class="fa fa-chevron-right ml-2"
                                                aria-hidden="true"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </div>
                <div class="item">
                    <li>
                        <div class="slider-info banner-view banner-top2 bg bg2">
                            <div class="banner-info">
                                <div class="container">
                                    <div class="banner-info-bg">
                                        <h5>A Great Place for Learning</h5>
                                        <p class="mt-4 pr-lg-4">
                                            Choose courses from the different fields and
                                            many new courses will be continue adding</p>
                                        <a class="btn btn-style btn-primary mt-xl-5 mt-4 mr-2" href="about.html"> Get
                                            Started <span class="fa fa-chevron-right ml-2"
                                                aria-hidden="true"></span></a>
                                        <a class="btn btn-style btn-white mt-xl-5 mt-4" href="services.html"> View
                                            Courses <span class="fa fa-chevron-right ml-2"
                                                aria-hidden="true"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </div>
                <div class="item">
                    <li>
                        <div class="slider-info banner-view banner-top3 bg bg2">
                            <div class="banner-info">
                                <div class="container">
                                    <div class="banner-info-bg">
                                        <h5>Learning to Love, Loving to Learn</h5>
                                        <p class="mt-4 pr-lg-4">
                                            Choose courses from the different fields and
                                            many new courses will be continue adding </p>
                                        <a class="btn btn-style btn-primary mt-xl-5 mt-4 mr-2" href="about.html"> Get
                                            Started <span class="fa fa-chevron-right ml-2"
                                                aria-hidden="true"></span></a>
                                        <a class="btn btn-style btn-white mt-xl-5 mt-4" href="services.html"> View
                                            Courses <span class="fa fa-chevron-right ml-2"
                                                aria-hidden="true"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </div>
            </div>
            <div class="w3l-banner-grids">
                <div class="bangrids-inn">
                    <div class="banhny-grid-1">
                        <div class="banhny-grid-icon">
                            <span class="fa fa-laptop"></span>
                        </div>
                        <div class="banhny-grid-right-info">
                            <h6><a href="#url">Many free online courses</a></h6>
                            <p>Focus is having the unwavering attention.</p>
                        </div>
                    </div>

                    <div class="banhny-grid-1">
                        <div class="banhny-grid-icon">
                            <span class="fa fa-book"></span>
                        </div>
                        <div class="banhny-grid-right-info">
                            <h6><a href="#url">Live learning</a></h6>
                            <p>Start with your goals in mind and then work.</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <div class="content-1 py-5">
        <div class="container py-md-5">
            <div class="row content-1-grids">
                <div class="col-lg-4 content-1-left forms-25-info">
                    <div class="header-title">
                        <span class="sub-title">About Us</span>
                        <h3 class="hny-title">Learn at Your Own Place</h3>

                    </div>
                </div>
                <div class="col-lg-4 content-1-right pl-lg-5 mt-lg-0 mt-4">
                    <p class="">We basically provide you the best filtered courses
                               from the internet and roadmaps of the different fields
                               so that you have a basic idea about what to do.
                    </p>
                </div>
                <div class="col-lg-4 content-1-right pl-lg-5 mt-lg-0 mt-4">
                    <p class="">

                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="w3l-homeblog py-5" id="homeblog">
        <div class="container py-lg-5 py-md-4">
            <div class="header-title mb-3">
                <span class="sub-title">Top Courses</span>
                <h3 class="hny-title text-left">Browse Our Top Courses.</h3>
            </div>
            <div class="row top-pics ">
                <div class="col-lg-3 col-md-6 mt-5">
                    <div class="top-pic1">
                        <div class="card-body blog-details">
                            <p class="course-sub">283 online courses</p>
                            <a href="services.html" class="blog-desc">Business
                            </a>
                            <div class="author align-items-center">
                                <img src="assets/images/admin.jpg" alt="" class="img-fluid rounded-circle">
                                <ul class="blog-meta">
                                    <ul class="blog-meta">
                                        <li class="meta-item blog-lesson">
                                            <span class="meta-value"> 40 Lessons </span>. <span
                                                class="meta-value text-bold"></span>
                                        </li>
                                    </ul>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mt-5">
                    <div class="top-pic2">
                        <div class="card-body blog-details">
                            <p class="course-sub">383 online courses</p>
                            <a href="services.html" class="blog-desc"> Datascience
                            </a>
                            <div class="author align-items-center">
                                <img src="assets/images/admin.jpg" alt="" class="img-fluid rounded-circle">
                                <ul class="blog-meta">
                                    <ul class="blog-meta">
                                        <li class="meta-item blog-lesson">
                                            <span class="meta-value"> 30 Lessons </span>. <span
                                                class="meta-value text-bold"></span>
                                        </li>
                                    </ul>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mt-5">
                    <div class="top-pic3">
                        <div class="card-body blog-details">
                            <p class="course-sub">483 online courses</p>
                            <a href="services.html" class="blog-desc">Computer Science
                            </a>
                            <div class="author align-items-center">
                                <img src="assets/images/admin.jpg" alt="" class="img-fluid rounded-circle">
                                <ul class="blog-meta">
                                    <ul class="blog-meta">
                                        <li class="meta-item blog-lesson">
                                            <span class="meta-value"> 30 Lessons </span>. <span
                                                class="meta-value text-bold"></span>
                                        </li>
                                    </ul>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mt-5">
                    <div class="top-pic4">
                        <div class="card-body blog-details">
                            <p class="course-sub">583 online courses</p>
                            <a href="services.html" class="blog-desc">Blockchain
                            </a>
                            <div class="author align-items-center">
                                <img src="assets/images/admin.jpg" alt="" class="img-fluid rounded-circle">
                                <ul class="blog-meta">
                                    <li class="meta-item blog-lesson">
                                        <span class="meta-value"> 20 Lessons </span>. <span
                                            class="meta-value text-bold"></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mt-5">
                    <div class="top-pic5">
                        <div class="card-body blog-details">
                            <p class="course-sub">283 online courses</p>
                            <a href="services.html" class="blog-desc">Web Development
                            </a>
                            <div class="author align-items-center">
                                <img src="assets/images/admin.jpg" alt="" class="img-fluid rounded-circle">
                                <ul class="blog-meta">
                                    <ul class="blog-meta">
                                        <li class="meta-item blog-lesson">
                                            <span class="meta-value"> 40 Lessons </span>. <span
                                                class="meta-value text-bold"></span>
                                        </li>
                                    </ul>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mt-5">
                    <div class="top-pic6">
                        <div class="card-body blog-details">
                            <p class="course-sub">383 online courses</p>
                            <a href="services.html" class="blog-desc">App Development
                            </a>
                            <div class="author align-items-center">
                                <img src="assets/images/admin.jpg" alt="" class="img-fluid rounded-circle">
                                <ul class="blog-meta">
                                    <ul class="blog-meta">
                                        <li class="meta-item blog-lesson">
                                            <span class="meta-value"> 30 Lessons </span>. <span
                                                class="meta-value text-bold"></span>
                                        </li>
                                    </ul>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mt-5">
                    <div class="top-pic7">
                        <div class="card-body blog-details">
                            <p class="course-sub">483 online courses</p>
                            <a href="services.html" class="blog-desc">Development
                            </a>
                            <div class="author align-items-center">
                                <img src="assets/images/admin.jpg" alt="" class="img-fluid rounded-circle">
                                <ul class="blog-meta">
                                    <ul class="blog-meta">
                                        <li class="meta-item blog-lesson">
                                            <span class="meta-value"> 30 Lessons </span>. <span
                                                class="meta-value text-bold"></span>
                                        </li>
                                    </ul>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mt-5">
                    <div class="top-pic8">
                        <div class="card-body blog-details">
                            <p class="course-sub">583 online courses</p>
                            <a href="services.html" class="blog-desc">Information Technology
                            </a>
                            <div class="author align-items-center">
                                <img src="assets/images/admin.jpg" alt="" class="img-fluid rounded-circle">
                                <ul class="blog-meta">
                                    <li class="meta-item blog-lesson">
                                        <span class="meta-value"> 20 Lessons </span>. <span
                                            class="meta-value text-bold"></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="readhny-btm text-center mx-auto mt-md-4">
                    <a class="btn btn-primary btn-style mt-md-5 mt-4" href="about.html">Read More <span
                            class="fa fa-chevron-right ml-2" aria-hidden="true"></span></a>
                </div>
            </div>
        </div>
    </div>
    <section class="w3l-newsletter">
        <!-- /form-25-section -->
        <div class="form-25-main py-5">
            <div class="container py-lg-5">
                <div class="forms-25-info">

                    <div class="header-title mb-md-5 mt-4">
                        <span class="sub-title">Subscribe to our Community</span>
                        <h3 class="hny-title text-left">Join our Community of Students</h3>
                    </div>
                    <!-- Join our community -->
                    <form action="/CR SYSTEM/index.php" method="post" class="signin-form mt-4 mb-2">
                        <div class="forms-gds">
                            <input type="text" name="Name_of_user" placeholder="Name" required />
                            <input type="email" name="Contact_mail" placeholder="Email" required />
                            <button class="btn btn-style btn-primary" id="submitForm" name="submitDetails">Subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!--//w3l-newsletter-->
    <!-- testimonials -->
    <section class="w3l-clients-1" id="testimonials">
        <!-- /grids -->
        <div class="cusrtomer-layout py-5">
            <div class="container py-lg-5 py-md-4">
                <div class="header-title mb-md-5 mb-4">
                    <span class="sub-title">Testimonials</span>
                    <h3 class="hny-title text-left">What People Say</h3>
                </div>
                <!-- /grids -->
                <div class="testimonial-row">
                    <div id="owl-demo1" class="owl-two owl-carousel owl-theme mb-md-3 mb-sm-5 mb-4">
                        <div class="item">
                            <div class="testimonial-content">
                                <div class="testimonial">
                                    <blockquote>
                                        <q>The course was very comprehensive and easy to understand.
                                          The instructors made sure that they are giving the information in a
                                          way that won't make me confused.Thank you so much for this great course!.</q>
                                    </blockquote>
                                </div>
                                <div class="testi-des">
                                    <div class="test-img">
                                        <img src="assets/images/team1.jpg" class="img-fluid" alt="client-img">
                                    </div>
                                    <div class="peopl align-self">
                                        <h4>Gloria Parker</h4>
                                        <p class="indentity">Student </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-content">
                                <div class="testimonial">
                                    <blockquote>
                                        <q>This is one of the best course I have completed. The course is organised
                                          in the best way to support learners.  After the course, I was able to identify
                                           my faults which I have done before.</q>
                                    </blockquote>
                                </div>
                                <div class="testi-des">
                                    <div class="test-img"><img src="assets/images/team2.jpg" class="img-fluid"
                                        alt="client-img">
                                </div>
                                    <div class="peopl align-self">
                                        <h4>Tommy sakura</h4>
                                        <p class="indentity">Student </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-content">
                                <div class="testimonial">

                                    <blockquote>
                                        <q>This course is very thorough and detailed. Great course,
                                          well done to the instructors.</q>
                                    </blockquote>

                                </div>
                                <div class="testi-des">
                                    <div class="test-img"><img src="assets/images/team3.jpg" class="img-fluid"
                                        alt="client-img">
                                    </div>
                                    <div class="peopl align-self">
                                        <h4>Bruce Bailey </h4>
                                        <p class="indentity">Student </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-content">
                                <div class="testimonial">
                                    <blockquote>
                                        <q>This is one of the best course I have completed. The course is organised
                                          in the best way to support learners.  After the course, I was able to identify
                                         my faults which I have done before.</q>
                                    </blockquote>

                                </div>
                                <div class="testi-des">
                                    <div class="test-img"><img src="assets/images/team3.jpg" class="img-fluid"
                                        alt="client-img">
                                    </div>
                                    <div class="peopl align-self">
                                        <h4>Ruth Edwards</h4>
                                        <p class="indentity">Student </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- /grids -->
        </div>
        <!-- //grids -->
    </section>
    <!-- //testimonials -->

    <!-- footer -->
    <section class="w3l-footer-29-main">
        <div class="footer-29 py-5">
            <div class="container py-lg-4">
                <div class="row footer-top-29">
                    <div class="col-lg-4 col-md-6 col-sm-7 footer-list-29 footer-1 pr-lg-5">
                        <div class="footer-logo mb-3">
                            <a class="navbar-brand" href="index.html">CR System</a>
                        </div>
                        <p>Our main aim is to put the value to the person who are trusting our courses..</p>
                        <div class="main-social-footer-29 mt-4">
                            <a href="#facebook" class="facebook"><span class="fa fa-facebook"></span></a>
                            <a href="#twitter" class="twitter"><span class="fa fa-twitter"></span></a>
                            <a href="#instagram" class="instagram"><span class="fa fa-instagram"></span></a>
                            <a href="#linkedin" class="linkedin"><span class="fa fa-linkedin"></span></a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-5 col-6 footer-list-29 footer-2 mt-sm-0 mt-5">

                        <ul>
                            <h6 class="footer-title-29">Usefull Links</h6>
                            <li><a href="about.html">About Us</a></li>
                            <li><a href="services.html">Courses</a></li>
                            <li><a href="#pricing"> Pricing plans</a></li>
                            <li><a href="#careers"> Careers</a></li>
                            <li><a href="blog.html"> Blog posts</a></li>
                            <li><a href="contact.php">Contact us</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-5 col-6 footer-list-29 footer-3 mt-lg-0 mt-5">
                        <h6 class="footer-title-29">More Info</h6>
                        <ul>
                            <li><a href="#profile">Profile</a></li>
                            <li><a href="#vision">Vision & Values</a></li>
                            <li><a href="#history">History</a></li>
                            <li><a href="#leader">Leadership</a></li>
                            <li><a href="#help">Help</a></li>
                            <li><a href="#support"> Support</a></li>
                        </ul>

                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-7 footer-list-29 footer-4 mt-lg-0 mt-5">
                        <h6 class="footer-title-29">Contact Info </h6>
                        <p><strong>Address :</strong>Kotri Kalan, Ashta, Near, Indore Road, Bhopal, Madhya Pradesh 466114.</p>
                        <p class="my-2"><strong>Phone :</strong>
                          <!-- <a href="tel:+91 23456799"> -->
                          +91 23456799
                        <!-- </a> -->
                      </p>
                        <p><strong>Email :</strong>
                          <!-- <a href="mailto:info@example.com"> -->
                            info@example.com
                        <!-- </a> -->
                      </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="w3l-copyright">
        <div class="container">
            <div class="row bottom-copies">
            <p class="col-lg-8 copy-footer-29">
                    All rights reserved by the group 130 <br>
                    Pranjal Singhal <br>
                    Jenil Savalia <br>
                    Naman Talwar<br>
                    Chandni Soni
    
                  </p>


                <div class="col-lg-4 footer-list-29">
                    <ul class="d-flex text-lg-right justify-content-center mt-lg-0 mt-3">
                        <li><a href="#careers"> Careers</a></li>
                        <li class="mx-lg-5 mx-md-4 mx-3"><a href="#privacymy-lg-0 my-4">Privacy Policy</a></li>
                        <li><a href="contact.html">Contact us</a></li>
                    </ul>
                </div>

            </div>
        </div>


        <button onclick="topFunction()" id="movetop" title="Go to top">
            &#10548;
        </button>
        <script>
            // When the user scrolls down 20px from the top of the document, show the button
            window.onscroll = function () {
                scrollFunction()
            };

            function scrollFunction() {
                if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                    document.getElementById("movetop").style.display = "block";
                } else {
                    document.getElementById("movetop").style.display = "none";
                }
            }

            // When the user clicks on the button, scroll to the top of the document
            function topFunction() {
                document.body.scrollTop = 0;
                document.documentElement.scrollTop = 0;
            }
        </script>
        <!-- /move top -->
    </section>


    <script src="assets/js/jquery-3.3.1.min.js"></script> <!-- Common jquery plugin -->

    <script src="assets/js/theme-change.js"></script><!-- theme switch js (light and dark)-->

    <script src="assets/js/owl.carousel.js"></script>
    <!-- script for banner slider-->
    <script>
        $(document).ready(function () {
            $('.owl-one').owlCarousel({
                loop: true,
                margin: 0,
                nav: false,
                responsiveClass: true,
                autoplay: true,
                autoplayTimeout: 5000,
                autoplaySpeed: 1000,
                autoplayHoverPause: false,
                responsive: {
                    0: {
                        items: 1,
                        nav: false
                    },
                    480: {
                        items: 1,
                        nav: false
                    },
                    667: {
                        items: 1,
                        nav: true
                    },
                    1000: {
                        items: 1,
                        nav: true
                    }
                }
            })
        })
    </script>
    <!-- //script -->
    <!-- magnific popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script>
        $(document).ready(function () {
            $('.popup-with-zoom-anim').magnificPopup({
                type: 'inline',

                fixedContentPos: false,
                fixedBgPos: true,

                overflowY: 'auto',

                closeBtnInside: true,
                preloader: false,

                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-zoom-in'
            });

            $('.popup-with-move-anim').magnificPopup({
                type: 'inline',

                fixedContentPos: false,
                fixedBgPos: true,

                overflowY: 'auto',

                closeBtnInside: true,
                preloader: false,

                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-slide-bottom'
            });
        });
    </script>
    <!-- //magnific popup -->
    <!-- /counter-->
    <script src="assets/js/counter.js"></script>
    <!-- //counter-->
    <!-- script for tesimonials carousel slider -->
    <script>
        $(document).ready(function () {
            $("#owl-demo1").owlCarousel({
                loop: true,
                margin: 20,
                nav: false,
                responsiveClass: true,
                responsive: {
                    0: {
                        items: 1,
                        nav: false
                    },
                    1000: {
                        items:2,
                        nav: false,
                        loop:true
                    }
                }
            })
        })
    </script>
    <!-- //script for tesimonials carousel slider -->

    <!--/MENU-JS-->
    <script>
        $(window).on("scroll", function () {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });

        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function () {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function () {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function () {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });
    </script>
    <!--//MENU-JS-->

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });
    </script>

    <script>
        $("#submitForm").click(function() {
           alert("Click on https://t.me/+3pi-qGuTedc0Yjll to join our community.");
       });
    </script>

<?php
    if ($_SERVER['REQUEST_METHOD']== 'POST'){
        $name_user = $_POST['Name_of_user']; 
        $Contact_Mail = $_POST['Contact_mail'];

$servername = "localhost";
$username = "root";
$password = "";
$database = "community_form";

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn){
    die("Sorry we failed to connect ".mysqli_connect_error());
}

else {
    echo "Connection was successfull<br>";
    $sql = "INSERT INTO `user_details` (`PERSONNAME`, `PERSONMAIL`) VALUES ('$name_user','$Contact_Mail')";
    $result = mysqli_query($conn, $sql);

    if ($result){
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your entry has been submitted successfully!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>';
      }
      else{
          // echo "The record was not inserted successfully because of this error ---> ". mysqli_error($conn);
          echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> We are facing some technical issue and your entry ws not submitted successfully! We regret the inconvinience caused!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>';
      }
}
    }
    ?>
    <!-- //disable body scroll which navbar is in active -->

    <!--bootstrap-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- //bootstrap-->

</body>

</html>
